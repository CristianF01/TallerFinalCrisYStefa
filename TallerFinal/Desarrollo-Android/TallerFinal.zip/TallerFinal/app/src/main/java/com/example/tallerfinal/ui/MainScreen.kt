package com.example.tallerfinal.ui
import com.example.tallerfinal.network.ClimaResponse
import com.example.tallerfinal.network.RetrofitHelper
import coil.compose.AsyncImage

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.tallerfinal.data.EntradaDiarioEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    isDarkTheme: Boolean,
    onToggleTheme: () -> Unit,
    viewModel: EntradaViewModel = viewModel()
) {
    val entradas by viewModel.entradas.collectAsState()
    var mostrandoFormulario by remember { mutableStateOf(false) }

    // 🌤 Clima: ciudad, texto e ícono
    var ciudad by remember { mutableStateOf("Bogota") }
    var climaTexto by remember { mutableStateOf("Clima no consultado") }
    var iconoClimaUrl by remember { mutableStateOf("") }
    var consultarClima by remember { mutableStateOf(false) }

    if (consultarClima) {
        LaunchedEffect(ciudad) {
            try {
                val apiKey = "be9fb8e85b792e44701641cbbe40ebbb"
                val response = RetrofitHelper.instancia.obtenerClima(ciudad, apiKey)

                climaTexto = "Clima en ${response.name}: ${response.main.temp}°C"

                if (!response.weather.isNullOrEmpty()) {
                    val iconCode = response.weather.first().icon
                    iconoClimaUrl = "https://openweathermap.org/img/wn/${iconCode}@2x.png"
                } else {
                    iconoClimaUrl = ""
                }

            } catch (e: Exception) {
                climaTexto = "Error: ${e.message}"
                iconoClimaUrl = ""
            }
            consultarClima = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mi Diario Digital") },
                actions = {
                    IconButton(onClick = onToggleTheme) {
                        Text(if (isDarkTheme) "☀️" else "🌙")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { mostrandoFormulario = !mostrandoFormulario }) {
                Text(if (mostrandoFormulario) "-" else "+")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            // 🌆 Campo de ciudad
            OutlinedTextField(
                value = ciudad,
                onValueChange = { ciudad = it },
                label = { Text("Ciudad") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            // ☁️ Botón clima
            Button(onClick = { consultarClima = true }) {
                Text("Consultar clima")
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 🌡 Texto del clima
            Text(climaTexto)

            // 🖼️ Icono del clima
            if (iconoClimaUrl.isNotEmpty()) {
                AsyncImage(
                    model = iconoClimaUrl,
                    contentDescription = "Icono del clima",
                    modifier = Modifier
                        .size(64.dp)
                        .padding(top = 8.dp)
                )
            }

            // ✍️ Formulario
            if (mostrandoFormulario) {
                AddEntryScreen { nuevaEntrada ->
                    viewModel.insertarEntrada(nuevaEntrada)
                    mostrandoFormulario = false
                }
            }

            // 📋 Entradas
            Text("Entradas", style = MaterialTheme.typography.headlineSmall)
            LazyColumn {
                items(entradas) { entrada ->
                    Card(modifier = Modifier
                        .padding(8.dp)
                        .fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(entrada.titulo, style = MaterialTheme.typography.titleMedium)
                            Text(entrada.fecha, style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(entrada.contenido, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }
    }
}

package com.example.tallerfinal.network

data class ClimaResponse(
    val name: String,
    val main: Main,
    val weather: List<Weather>
)

data class Main(
    val temp: Double
)

data class Weather(
    val icon: String,
    val description: String
)

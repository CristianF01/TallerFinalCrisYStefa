package com.example.tallerfinal.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.tallerfinal.data.AppDatabase
import com.example.tallerfinal.data.EntradaDiarioEntity
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class EntradaViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        AppDatabase::class.java,
        "mi_diario.db"
    ).build()

    private val _entradas = MutableStateFlow<List<EntradaDiarioEntity>>(emptyList())
    val entradas: StateFlow<List<EntradaDiarioEntity>> = _entradas.asStateFlow()

    init {
        viewModelScope.launch {
            db.entradaDao().obtenerTodos().collect {
                _entradas.value = it
            }
        }
    }

    fun insertarEntrada(entrada: EntradaDiarioEntity) {
        viewModelScope.launch {
            db.entradaDao().insertar(entrada)
        }
    }
}

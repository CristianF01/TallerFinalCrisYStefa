package com.example.tallerfinal.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EntradaDao {
    @Insert
    suspend fun insertar(entrada: EntradaDiarioEntity)

    @Query("SELECT * FROM entradas ORDER BY id DESC")
    fun obtenerTodos(): Flow<List<EntradaDiarioEntity>>
}

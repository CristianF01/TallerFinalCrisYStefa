package com.example.tallerfinal.preferences

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit




val Context.dataStore by preferencesDataStore("ajustes")

class Preferencias(private val context: Context) {
    private val DARK_MODE = booleanPreferencesKey("modo_oscuro")

    val modoOscuro = context.dataStore.data.map { it[DARK_MODE] ?: false }

    suspend fun guardarModoOscuro(valor: Boolean) {
        context.dataStore.edit { it[DARK_MODE] = valor }
    }
}

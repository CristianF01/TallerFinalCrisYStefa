package com.example.tallerfinal.ui


import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.tallerfinal.data.EntradaDiarioEntity

@Composable
fun AddEntryScreen(onEntryAdded: (EntradaDiarioEntity) -> Unit) {
    var titulo by remember { mutableStateOf("") }
    var contenido by remember { mutableStateOf("") }
    var fecha by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(8.dp)) {
        OutlinedTextField(value = titulo, onValueChange = { titulo = it }, label = { Text("Título") })
        OutlinedTextField(value = contenido, onValueChange = { contenido = it }, label = { Text("Contenido") })
        OutlinedTextField(value = fecha, onValueChange = { fecha = it }, label = { Text("Fecha") })
        Button(onClick = {
            if (titulo.isNotBlank() && contenido.isNotBlank() && fecha.isNotBlank()) {
                onEntryAdded(EntradaDiarioEntity(titulo = titulo, contenido = contenido, fecha = fecha))
                titulo = ""
                contenido = ""
                fecha = ""
            }
        }) {
            Text("Guardar")
        }
    }
}

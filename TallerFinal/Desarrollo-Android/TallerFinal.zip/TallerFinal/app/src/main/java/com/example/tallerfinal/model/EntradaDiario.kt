package com.example.tallerfinal.model

data class EntradaDiario(
    val titulo: String,
    val contenido: String,
    val fecha: String
)
